// Add Favico to checkout Tab
var addIconTab = function () {
  var link = document.querySelector("link[rel~='icon']");
  if (!link) {
    link = document.createElement("link");
    link.rel = "icon";
    document.getElementsByTagName("head")[0].appendChild(link);
  }
  link.href = "/arquivos/FAVICON.png";
};
const addDepartmentInCalc = function () {
  setInterval(function () {
    try {
      document.querySelector("#deliver-at-text .srp-address-title").innerHTML =
        vtexjs.checkout.orderForm.shippingData.address.state +
        ", " +
        vtexjs.checkout.orderForm.shippingData.address.city;
    } catch (error) { }
  }, 1000);
};
var pasosCheckout = function (location) {
  var statusCheckout = {
    step1: "cart",
    step2: "email",
    step3: "profile",
    step4: "shipping",
    step5: "payment",
    step4: "orderPlaced",
  };

  function assignClassStep(step) {
    var htmlStep = setInterval(function () {
      if ($("#progressbar li").length) {
        clearInterval(htmlStep);
        $("#progressbar li").removeClass("active");
        $('#progressbar li[data-step*="' + step + '"').addClass("active");
      }
    }, 500);
  }

  if (location.indexOf(statusCheckout.step1) > -1) {
    assignClassStep(statusCheckout.step1);
  }
  if (location.indexOf(statusCheckout.step2) > -1) {
    assignClassStep(statusCheckout.step2);
  }
  if (
    location.indexOf(statusCheckout.step3) > -1 ||
    location.indexOf(statusCheckout.step4) > -1 ||
    location.indexOf(statusCheckout.step5) > -1
  ) {
    assignClassStep(statusCheckout.step3);
  }
  if (location.indexOf(statusCheckout.step6) > -1) {
    assignClassStep(statusCheckout.step6);
  }
};
var validateStep = function () {
  var step = window.location.hash.replace("#/", "");

  if (step === "profile") {
    /*setTimeout(function () {
            $('#go-to-shipping:visible').prop(
                'disabled',
                !$('#input__terms').prop('checked')
            );
        }, 0);*/

    if (checkout.loggedIn() && clientProfileData.email()) {
      $("body").addClass("loggedIn");
    } else {
      $("body").removeClass("loggedIn");
    }
  }

  if (step === "email") {
    $(".client-profile-data.accordion-group, #shipping-data").hide();
  } else {
    $(".client-profile-data.accordion-group, #shipping-data").show();
  }
};
$("#is-not-me").click(function () {
  let idorder = vtexjs.checkout.orderForm.orderFormId;
  vtexjs.checkout.orderForm = {};
  fetch("/checkout/changeToAnonymousUser/" + idorder).then(function () {
    window.location.reload();
  });
});
var getOderForm = () => {
  return vtexjs.checkout.orderForm ? vtexjs.checkout.orderForm : false;
};
var skuProductList = function () {
  var orderForm = getOderForm();
  if (!orderForm) {
    return;
  }

  try {
    $.each(orderForm.items, function (i) {
      var skuCustom = $(
        `.table.cart-items tbody tr.product-item:eq(${i}) td.product-name`
      ).find(".product-sku-custom");
      if (skuCustom.length === 0) {
        $(
          `<div class="product-sku-custom">SKU: ${orderForm.items[i].productRefId}</div>`
        ).appendTo(
          `.table.cart-items tbody tr.product-item:eq(${i}) td.product-name`
        );
      }
    });
  } catch (e) {
    console.log("error product list", e);
  }

  try {
    $.each(orderForm.items, function (i) {
      var skuCustom = $(
        `.cart-fixed .summary-cart-template-holder .cart-items:eq(${i}) .product-name`
      ).find(".product-sku-custom");
      if (skuCustom.length === 0) {
        $(
          `<div class="product-sku-custom">SKU: ${orderForm.items[i].productRefId}</div>`
        ).appendTo(
          `.cart-fixed .summary-cart-template-holder .cart-items:eq(${i}) .product-name`
        );
      }
    });
  } catch (e) {
    console.log("error product list", e);
  }
};

var skuProductListLast = function () {
  var orderForm = getOderForm();
  // console.log('orderForm', orderForm);
  if (!orderForm) {
    return;
  }

  try {
    $.each(orderForm.items, function (i) {
      var skuCustom = $(
        `.cart-fixed .summary-cart-template-holder .cart-items:eq(${i}) .product-name`
      ).find(".product-sku-custom");
      if (skuCustom.length === 0) {
        $(
          `<div class="product-sku-custom">SKU: ${orderForm.items[i].productRefId}</div>`
        ).appendTo(
          `.cart-fixed .summary-cart-template-holder .cart-items:eq(${i}) .product-name`
        );
      }
    });
  } catch (e) {
    console.log("error product list", e);
  }
};
const changeTextPlaceholder = () => {
  setTimeout(function () {
    $("#client-pre-email").attr("placeholder", "Ingresa tu correo electrónico");
  }, 1000);
};
const addProductVitrine = () => {
  fetch(
    "/api/catalog_system/pub/products/search/?fq=productClusterIds:148&O=OrderByTopSaleDESC&_from=0&_to=2"
  )
    .then(function (response) {
      response.json().then(function (data) {
        var cont = 0;
        var contentHtml = "";
        contentHtml +=
          '<h3 class="titleVitrine">Completa tu compra</h3> <div class="d-flex container-checkoutResume">';
        $(".wrapperVitrineProduct").length == 0
          ? $(".checkout-container.row-fluid.cart-active").after(
            "<div class='wrapperVitrineProduct'></div>"
          )
          : false;
        $.each(data, function (index, value) {
          var productSku = value.items[0].itemId.toString();
          var productName = value.productName;
          var productPrice = toMoney(
            value.items[0].sellers[0].commertialOffer.Price
          )
            .toString()
            .replace(/.[^.]+$/, "")
            .replace(",", ".");
          var productImage = value.items[0].images[0].imageUrl;
          contentHtml += `<div class="contentProductItem">
                                <div class="itemProductBox">
                                  <div class="imagePdtoItem"><img src="${replaceSize(
            productImage,
            280,
            280
          )}" alt="${productName}"/></div>
                                  <div class="namePdtoItem">
                                    ${productName}
                                  </div>
                                  <div class="pricePdtoItem">
                                    ${productPrice}
                                  </div>
                                </div>
                                <div class="btnProduct">
                                  <a style="cursor:pointer" class="addProduct" data-skuid="${productSku}">Agregar al carrito </a>
                                </div>
                              </div>`;
        });
        contentHtml += "</div>";

        $(".wrapperVitrineProduct").html(contentHtml);
      });
    })
    .catch(function (err) {
      console.error("Fetch Error :-S", err);
    });
};
const changeCHStructure = () => {
  // Add product to cart in click event
  $(document).on("click", ".addProduct", (e) => {
    var idProductSku = $(e.currentTarget).attr("data-skuid");
    $.ajax({
      url:
        "/checkout/cart/add?sku=" +
        idProductSku +
        "&qty=1&seller=1&redirect=false&sc=1",
      method: "GET",
      success: function () {
        window.location.reload();
      },
      error: function (error) {
        console.log(error);
      },
    });
  });
};
const addTextPayments = function () {
  if ($(".payment-select-bank").length) {
    if ($("#info-bank-payment").length) {
      $("#info-bank-payment").html(
        "<br>Por favor verificar con el Banco los montos máximos de compras por internet y Tener en cuenta que el pago mínimo de compra en este sitio es de $1.600 "
      );
    } else {
      $(".debitPaymentGroup")
        .children(".payment-select-bank")
        .siblings(".clearfix")
        .append(
          "<p id='info-bank-payment'><br>Por favor verificar con el Banco los montos máximos de compras por internet y Tener en cuenta que el pago mínimo de compra en este sitio es de $1.600 </p>"
        );
    }
  }

  if ($("#iframe-placeholder-creditCardPaymentGroup").length) {
    if ($("#info-credit-payment").length) {
      $("#info-credit-payment").html(
        "<br>Por favor verificar con el Banco los montos máximos de compras por internet y Tener en cuenta que el pago mínimo de compra en este sitio es de $1.000 y el pago máximo es de $30.000.000"
      );
    } else {
      $("#iframe-placeholder-creditCardPaymentGroup").append(
        "<p id='info-credit-payment'><br>Por favor verificar con el Banco los montos máximos de compras por internet y Tener en cuenta que el pago mínimo de compra en este sitio es de $1.000 y el pago máximo es de $30.000.000 </p>"
      );
    }
  }

  if ($(".payment-select-bank").length) {
    if ($("#info-bankInvoice-payment").length) {
      let paymentData = vtexjs.checkout.orderForm.paymentData;
      let paymentSystems = paymentData.paymentSystems;
      let paymentId = paymentData.payments[0].paymentSystem;

      let paymentName = paymentSystems.filter(
        (paymentSystem) => paymentSystem.stringId === paymentId
      )[0].name;
      if (paymentName === "EFECTY") {
        //efecty
        $("#info-bankInvoice-payment").html(
          "Tener en cuenta que el pago mínimo de compra en este sitio y por este medio de pago es de $5.000 y el pago máximo es de $8.000.000"
        );
      } else if (paymentName === "BALOTO") {
        //baloto
        $("#info-bankInvoice-payment").html(
          "Tener en cuenta que el pago mínimo de compra en este sitio y por este medio de pago es de $1.000 y el pago máximo es de $1.000.000"
        );
      }
    } else {
      let paymentData = vtexjs.checkout.orderForm.paymentData;
      let paymentSystems = paymentData.paymentSystems;
      let paymentId = paymentData.payments[0].paymentSystem;

      let paymentName = paymentSystems.filter(
        (paymentSystem) => paymentSystem.stringId === paymentId
      )[0].name;
      if (paymentName === "EFECTY") {
        //efecty
        $(".bankInvoicePaymentGroup")
          .children(".payment-select-bank")
          .siblings(".clearfix")
          .append(
            "<p id='info-bankInvoice-payment'>Tener en cuenta que el pago mínimo de compra en este sitio y por este medio de pago es de $5.000 y el pago máximo es de $8.000.000</p>"
          );
      } else if (paymentName === "BALOTO") {
        //baloto
        $(".bankInvoicePaymentGroup")
          .children(".payment-select-bank")
          .siblings(".clearfix")
          .append(
            "<p id='info-bankInvoice-payment'>Tener en cuenta que el pago mínimo de compra en este sitio y por este medio de pago es de $1.000 y el pago máximo es de $1.000.000</p>"
          );
      }
    }
  }

  if ($("#iframe-placeholder-customPrivate_501PaymentGroup").length) {
    if ($("#info-codensa-payment").length) {
      $("#info-codensa-payment").html(
        "Tener en cuenta que el pago máximo de compra en este sitio es de $5.000.000"
      );
    } else {
      $("#iframe-placeholder-customPrivate_501PaymentGroup").append(
        "<p id='info-codensa-payment'>Tener en cuenta que el pago máximo de compra en este sitio es de $5.000.000</p>"
      );
    }
  }

  if ($("#iframe-placeholder-debitCardPaymentGroup").length) {
    if ($("#info-debitcard-payment").length) {
      $("#info-debitcard-payment").html("<br>");
    } else {
      $("#iframe-placeholder-debitCardPaymentGroup").append(
        "<p id='info-debitcard-payment'><br></p>"
      );
    }
  }
};
// replace size in CH image
function replaceSize(url, width, height) {
  const id = url.match(/\/\d{6}/)[0];
  const newURL = url.replace(id, `${id}-${width}-${height}`);
  return newURL;
}

// Change number to money
function toMoney(str, currency_sign) {
  currency_sign = currency_sign || "$";
  var current = Number(str?.toString().replace(/[^0-9.]/g, ""));
  var formatted = current.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,");
  return currency_sign + formatted;
}

$(window).on("hashchange", function () {
  pasosCheckout(location.pathname + location.hash);
  addDepartmentInCalc();
  changeTextPlaceholder();
  validateStep();
  changeCHStructure();
});
$(window).load(function () {
  setTimeout(function () {
    skuProductList();
  });

  setTimeout(() => {
    skuProductListLast();
  }, 1000);
});
$(window).on("hashchange", function (e) {
  setTimeout(function () {
    skuProductList();
  });

  setTimeout(() => {
    skuProductListLast();
  }, 1000);
  if ($("#edit-profile").length > 0) {
    //console.log($('#edit-profile').length);
  } else {
    $(".client-profile-data.filled").append(
      "<a id='edit-profile' href='/account#/profile'> Editar datos desde Mi cuenta</a>"
    );
  }
});
$(window).on("orderFormUpdated.vtex", function () {
  setTimeout(function () {
    skuProductList();
  });

  setTimeout(() => {
    skuProductListLast();
  }, 1000);
});
$(document).ready(function () {
  pasosCheckout(location.pathname + location.hash);
  skuProductList();
  skuProductListLast();
  changeTextPlaceholder();
  $(".mini-cart .summary-template-holder").append(
    '<div class="mini-cart__continue">Continuar</div>'
  );
  $(
    '<p class="terms">' +
    '<label class="checkbox">' +
    '<input type="checkbox" id="input__terms">' +
    '<span class="terms__text">He leído y acepto los <a href="https://www.tienda.komatsu.com.co/terminos-y-condiciones" target="_blank">Términos y condiciones</a> y las <a href="https://www.tienda.komatsu.com.co/proteccion-datos" target="_blank">Políticas de uso de cookies</a></span>' +
    "</label>" +
    "</p>"
  ).insertBefore(".newsletter");
  $(document).on("click", ".mini-cart__continue", function () {
    var step = window.location.hash.replace("#/", "");

    if (step === "profile") {
      $(".form-step").submit();
    } else if (step === "shipping") {
      $(".btn-go-to-payment").click();
    }
  });
  validateStep();

  setTimeout(() => {
    const premail = document.querySelector(
      ".form-page.client-pre-email #client-pre-email"
    );

    premail.placeholder = "Ingresa tu correo electronico";
  }, 1000);
  if ($("#edit-profile").length > 0) {
    //console.log($('#edit-profile').length);
  } else {
    $(".client-profile-data.filled").append(
      "<a id='edit-profile' href='/account#/profile'> Editar datos desde Mi cuenta</a>"
    );
  }
});

$(window).on("load", function () {
  addProductVitrine();
  changeCHStructure();
  //updateFormClient();
  changeTextPlaceholder();
  addDepartmentInCalc();
  setInterval(() => {
    addTextPayments();
  }, 500);
  $("#is-not-me").attr("href", "#");
  $("#is-not-me").click(function () {
    let idorder = vtexjs.checkout.orderForm.orderFormId;
    vtexjs.checkout.orderForm = {};
    fetch("/checkout/changeToAnonymousUser/" + idorder).then(function () {
      window.location.reload();
    });
  });
  if ($("#edit-profile").length > 0) {
  } else {
    $(".client-profile-data.filled").append(
      "<a id='edit-profile' href='/account#/profile'> Editar datos desde Mi cuenta</a>"
    );
  }
  
  setupAdvisorSelect();
});
addIconTab();
$(function () {
  const customCheckoutInit = function () {
    docTypeSelector();
    addFieldsInfo();
    validateDocumentType();
    validateDocument();

    setTimeout(function () {
      getScript("/files/new-departments.json").done(function (data) {
        departamentos = JSON.parse(data);
        addDaneCode();
      });
    }, 2000);

    $(document).on("change", "#client-doc-type", function (e) {
      const selectedValue = $(this).val();
      checkDocTypeExistSet(selectedValue);
    });
    $(document).on("change", "#client-document2", function (e) {
      if ($("#client-doc-type").val() !== "13 - Cédula de Ciudadanía") {
        clientProfileData.alternateDocument(e.target.value);
      }
    });
  };
  var getScript = function getScript(url, cb) {
    return jQuery.ajax({
      url: url,
      dataType: "script",
      success: function success(data) {
        if (typeof cb === "function") cb();
        return data;
      },
      async: true,
    });
  };
  const checkDocTypeExistSet = function (selectedValue) {

    $("#client-document-type").val(selectedValue);
    console.log(selectedValue);
    if (selectedValue != "13 - Cédula de Ciudadanía") {
      clientProfileData.hasDifferentDocument(true);
      clientProfileData.alternateDocumentType(selectedValue);
    } else {
      clientProfileData.toggleDifferentDocument();
      clientProfileData.document.validate();
      clientProfileData.hasDifferentDocument(false);
    }
  };
  const addDaneCode = () => {
    const selectdepartamento = document.querySelector("#client-department");
    const selectmunicipio = document.querySelector("#client-municipality");

    selectdepartamento.addEventListener("change", mostrarMunicipio);

    const Newdepartments = [...new Set(departamentos.map(item => item.Departamento))];

    console.log(Newdepartments, departamentos)

    Newdepartments.forEach((departamento) => {
      let option = document.createElement("option");
      let atributo = document.createAttribute("value");
      atributo.value = departamento;
      option.setAttributeNode(atributo);
      option.innerHTML = departamento.toUpperCase();
      selectdepartamento.appendChild(option);
    });


    mostrarMunicipio();

    function mostrarMunicipio() {
      const valordepartamento = selectdepartamento.value;
      if (valordepartamento !== "") {
        let municipios = departamentos.filter((prov) => prov.Departamento === valordepartamento);
        selectmunicipio.innerHTML = '<option value="">Seleccione</option>';
        municipios.forEach((municipio) => {
          let option = document.createElement("option");
          option.value = municipio.Code;
          option.innerHTML = municipio.Name.toUpperCase();
          selectmunicipio.appendChild(option);
        });
      } else {
        selectmunicipio.innerHTML = '<option value="">Seleccione</option>';
      }
    }

  };
  const docTypeSelector = function () {
    const $docTypeSelect = $("<select>").attr("id", "client-doc-type");
    const $originaldocTypSelect = $("#client-document-type");
    const $docTypeOptions = `
            <option value="13 - Cédula de Ciudadanía">Cédula de Ciudadanía</option>
            <option value="22 - Cédula de extranjería">Cédula de extranjería</option>
            <option value="31 - NIT">NIT</option>
            <option value="41 - Pasaporte">Pasaporte</option>
        `;

    $($docTypeOptions).appendTo($docTypeSelect);
    $originaldocTypSelect.before($docTypeSelect);
    $(".client-document-type").insertBefore(".client-document");

    // Aca determinamos si antes ya hay algun valor guardado en el 'input', para cambiar el valor que trae por defecto nuestro 'select'
    if ($originaldocTypSelect.val().length > 0) {
      $docTypeSelect.find("option").removeAttr("selected");

      // buscamos la opcion que tenga el 'input' original para agregar el atributo 'selected' y nos lo muestre por defecto
      $docTypeSelect
        .find('option[value="' + $originaldocTypSelect.val() + '"]')
        .prop("selected", "selected");
    }

    var checkDocTypeExist = function (selectedValue) {

      $("#client-document-type").val(selectedValue);
      $("#client-document-type").addClass("success").trigger("keydown");
      $("#client-new-document").removeClass("success");
    };
    $(document).on("change", "#client-doc-type", function (e) {
      const selectedValue = $(this).val();
      checkDocTypeExist(selectedValue);
    });

    // Evento que escucha al dar click al seleccionar otro documento, para se disparen los eventos de nuestro 'select'
    $(document).on("click", ".links-other-document.links", function () {
      $("#client-doc-type").trigger("change");
    });
  };
  var validateDocument = function () {
    $("#client-document,#client-new-document").keydown(function (e) {
      // Allow: backspace, delete, tab, escape, enter and .
      if ($("#client-doc-type").val() == "13 - Cédula de Ciudadanía") {
        if (
          $.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
          // Allow: Ctrl+A, Command+A
          (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
          // Allow: home, end, left, right, down, up
          (e.keyCode >= 35 && e.keyCode <= 40)
        ) {
          // let it happen, don't do anything
          return;
        }
        // Ensure that it is a number and stop the keypress
        if (
          (e.shiftKey || e.keyCode < 48 || e.keyCode > 57) &&
          (e.keyCode < 96 || e.keyCode > 105)
        ) {
          e.preventDefault();
        }
      }
    });
  };
  const validateDocumentType = function () {
    clientProfileData.documentType.subscribe(function (val) {
      $("#client-doc-type").find("option").removeAttr("selected");
      $("#client-doc-type")
        .find('option[value="' + val + '"]')
        .prop("selected", "selected");

      if (val && val !== "dni") {
        $("#client-document2").val(clientProfileData.alternateDocument());
      }
    });
  };
  const addFieldsInfo = function () {
    const contentInfoClient = document.querySelector(".box-client-info-pf");
    const contentInfoClientCompany = document.querySelector(".corporate-info-box");
    const phone = document.querySelector('div[data-bind="template: {name: phoneTemplate(), afterRender: window.vtex.i18n.translateHtml }"]');

    const department = document.createElement("p");
    department.className = "client-department input pull-left text required";
    department.innerHTML = `
        <label for="client-department" data-i18n="clientProfileData.client-department">Departamento</label>
        <select id="client-department" autocomplete="client-department" class="input-small">
            <option value="">Seleccione</option>
        </select>
      `;

    const municipality = document.createElement("p");
    municipality.className = "client-municipality input pull-left text required";
    municipality.innerHTML = `
        <label for="client-municipality" data-i18n="clientProfileData.client-municipality">Municipio</label>
        <select id="client-municipality" autocomplete="client-municipality" class="input-small">
            <option value="">Seleccione</option>
        </select>
      `;

    const PostalCode = document.createElement("p");
    PostalCode.className = "client-PostalCode input pull-left text required";
    PostalCode.innerHTML = `
        <label for="client-PostalCode" data-i18n="clientProfileData.client-PostalCode">Código Postal</label>
        <input type="text" id="client-PostalCode" autocomplete="client-PostalCode" class="input-small">
      `;

    const address = document.createElement("p");
    address.className = "client-address input pull-left text required";
    address.innerHTML = `
        <label for="client-address" data-i18n="clientProfileData.client-address">Dirección de Facturación</label>
        <input type="text" id="client-address" autocomplete="client-address" class="input-small">
      `;

    const documentType = document.querySelector(".client-document-type");
    const name3 = document.querySelector(".client-last-name");

    contentInfoClient.insertBefore(documentType, name3);
    contentInfoClient.insertBefore(department, phone);
    contentInfoClient.insertBefore(municipality, phone);
    contentInfoClient.insertBefore(address, phone);

    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css';
    document.head.appendChild(link);


    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js';
    document.body.appendChild(script);

    script.onload = function () {
      const economicActivity = document.createElement("p");
      economicActivity.className = "client-company-economicActivity input pull-left text required";

      const economicActivitySelect = document.createElement("select");
      economicActivitySelect.className = "input-small";
      economicActivitySelect.id = "client-company-economicActivity";

      economicActivity.innerHTML = `
          <label for="client-company-economicActivity" data-i18n="clientProfileData.client-company-economicActivity">Actividad económica</label>
        `;
      economicActivity.appendChild(economicActivitySelect);
      economicActivitySelect.innerHTML = `
          <option value="">Seleccione</option>
        `;

      const url = "/files/actividad-economica.json";
      const requestOptions = {
        headers: {
          accept: "*/*",
          "content-type": "application/json; charset=UTF-8",
        },
        method: "GET",
      };

      fetch(url, requestOptions)
        .then((response) => response.json())
        .then(function (res) {
          res.forEach((activity) => {
            let option = document.createElement("option");
            option.value = activity.id;
            option.textContent = `${activity.id} - ${activity.actividadEconomica}`;
            economicActivitySelect.appendChild(option);
          });

          $(economicActivitySelect).select2({
            placeholder: "Seleccione una actividad",
            allowClear: true,
            width: "100%",
            height: "40px",
            minimumResultsForSearch: 1,
            language: {
              noResults: function () {
                return "No se encontraron resultados";
              },
            },
          });
          contentInfoClientCompany.insertBefore(economicActivity, document.querySelector(".client-company-document.pull-left"));

          $(contentInfoClientCompany).on('click', function () {
            $('.select2-container--default .select2-search--dropdown .select2-search__field').attr('placeholder', 'Buscar');
          });


        })
        .catch(function (error) {
          console.log(error);
        });

      const firstNameInput = document.getElementById("client-first-name");
      firstNameInput.name = "firstname";

      const lastNameInput = document.getElementById("client-last-name");
      lastNameInput.name = "lastname";

      const docTypeInput = document.getElementById("client-doc-type");
      docTypeInput.name = "tipo_del_documento";

      const docInput = document.getElementById("client-document");
      const docInput2 = document.getElementById("client-document2");
      docInput.name = "cedula_de_ciudadania";
      const docNewInput = document.getElementById("client-new-document");

      docNewInput.addEventListener("blur", function () {
        docInput.value = docNewInput.value;
      });
    };

    const selfRetainer = document.createElement("p");
    selfRetainer.className = "client-company-selfRetainer input pull-left text required";
    selfRetainer.innerHTML = `
        <label for="client-company-selfRetainer" data-i18n="clientProfileData.client-company-selfRetainer">Es autoretenedor</label>
        <select id="client-company-selfRetainer" autocomplete="client-company-selfRetainer" class="input-small">
            <option value="">Seleccione</option>
            <option value="Y">Si</option>
            <option value="N">No</option>
        </select>
      `;

    const taxRegime = document.createElement("p");
    taxRegime.className = "client-company-taxRegime input pull-left text required";
    taxRegime.innerHTML = `
        <label for="client-company-taxRegime" data-i18n="clientProfileData.client-company-taxRegime">Régimen tributario</label>
        <select id="client-company-taxRegime" autocomplete="client-company-taxRegime" class="input-small">
            <option value="">Seleccione</option>
            <option value="AU">AU - Autoretenedor Renta</option>
            <option value="CE">CE - Exterior</option>
            <option value="GC">GC - Gran Contribuyente</option>
            <option value="NI">NI - No Responsable de IVA</option>
            <option value="PH">PH - Propiedad Horizonta</option>
            <option value="RC">RC - Régimen Comun</option>
            <option value="RE">RE - Régimen Especial</option>
            <option value="RO">RO - Régimen Ordinario</option>
            <option value="RS">RS - Régimen Simplificado</option>
            <option value="RI">RI - Responsable de IVA</option>
        </select>
      `;
    contentInfoClientCompany.insertBefore(selfRetainer, document.querySelector(".client-company-document.pull-left"));
    contentInfoClientCompany.insertBefore(taxRegime, document.querySelector(".client-company-document.pull-left"));

    const addressInput = document.getElementById("client-address");
    addressInput.name = "address";

    const companyInput = document.getElementById("client-company-name");
    companyInput.name = "empresa";

    const empresaInput = document.getElementById("client-company-nickname");
    empresaInput.name = "company";

    const nitInput = document.getElementById("client-company-ie");
    nitInput.name = "nit";

    const btnGoToShipping = document.querySelector("#go-to-shipping");

    btnGoToShipping.addEventListener("click", updateClient);

    function updateClient() {
      var email = $("#client-email").val();
      const phone = $("#client-phone").val();
      const clientDocument = $("#client-document").val();
      const documentType = $("#client-doc-type").val();
      const clientCity = $("#client-municipality").val();
      const clientDepartment = $("#client-department").val();
      const clientPostalCode = departamentos.find((prov) => prov.Code == clientCity);
      const clientAddress = $("#client-address").val();
      const economicActivity = $("#client-company-economicActivity").val();
      const fiscalObligations = $("#client-company-fiscalObligations").val();
      const receptorRegimen = $("#client-company-receptorRegimen").val();
      const selfRetainer = $("#client-company-selfRetainer").val();
      const taxRegime = $("#client-company-taxRegime").val();
      const clientNameCity = $("#client-municipality option:selected").text();
      const clientNameDepartament = $(
        "#client-department option:selected"
      ).text();

      const clientName = $('#client-first-name').val()
      const clientLastname = $('#client-last-name').val()

      clientProfileData.documentType(documentType);

      var myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/json");

      if (
        $("#client-email").val() !== "" &&
        $(".corporate-title").hasClass("visible")
      ) {

        const userData = {
          clientAddress: clientAddress,
          clientCity: clientCity,
          clientDepartment: clientDepartment,
          clientPostalCode: clientPostalCode,
          documentType: documentType,
          secondLastName: clientLastname,
          secondName: clientName,
          email: email,
          economicActivity: economicActivity,
          fiscalObligations: fiscalObligations,
          receptorRegimen: receptorRegimen,
          selfRetainer: selfRetainer,
          taxRegime: taxRegime,
          phone: phone,
          document: clientDocument,
          clientNameCity: clientNameCity,
          clientNameDepartament: clientNameDepartament,
        };

        var requestOptions = {
          method: "PATCH",
          headers: myHeaders,
          body: JSON.stringify(userData),
          redirect: "follow",
        };
      } else {
        const userData = {
          clientAddress: clientAddress,
          clientCity: clientCity,
          clientDepartment: clientDepartment,
          clientPostalCode: clientPostalCode,
          documentType: documentType,
          secondLastName: secondLastName,
          secondName: secondName,
          email: email,
          phone: phone,
          document: clientDocument,
          clientNameCity: clientNameCity,
          clientNameDepartament: clientNameDepartament,
        };
        var requestOptions = {
          method: "PATCH",
          headers: myHeaders,
          body: JSON.stringify(userData),
          redirect: "follow",
        };
      }
      $(".client-name-4").append(
        '<span class="help error" style="display:none">Este campo es obligatorio.</span>'
      );

      fetch("/api/dataentities/DC/documents", requestOptions)
        .then((response) => response.text())
        .then((result) => console.log(result, "result"))
        .catch((error) => console.log("error", error));
      $("#go-to-shipping").removeAttr("disabled");
      $("#go-to-payment").removeAttr("disabled");

    }

  };

  customCheckoutInit();
});

function fetchDataAndPopulateSelect(apiEndpoint, targetElementId) {
  const dataShareValue = "codigo";

  // Función para mostrar el loader
  function showLoader() {
    const loader = document.createElement("div");
    loader.id = "loader";
    loader.innerHTML = "Cargando...";
    const swalTitleElement = document.getElementById("swal2-title");
    if (swalTitleElement) {
      swalTitleElement.insertAdjacentElement("afterend", loader);
    }
  }

  // Función para ocultar el loader
  function hideLoader() {
    const loader = document.getElementById("loader");
    if (loader) {
      loader.remove();
    }
  }

  async function fetchData() {
    try {
      showLoader();
      const response = await fetch(apiEndpoint, {
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          Accept: "application/vnd.vtex.ds.v10+json",
          "x-vtex-api-appKey": "vtexappkey-komatsu-FQSTTA",
          "x-vtex-api-appToken":
            "WCWBQTSLPEJYPYLXFBURDZZBORBXMLNLIQCNEISNLOHCPILQEYTPZJIPUWVANIHNOQWZYQWVJXOOBCFDTYEJHDLRXPJBYKXZNFQDGORECTKZBXHNGSNLUGANJJRDHRMJ",
        },
      });

      const data = await response.json();
      console.log(data);

      const selectElement =
        document.getElementById(targetElementId) ||
        document.createElement("select");
      selectElement.innerHTML = "";
      selectElement.id = "dynamicSelectCodeSelling";

      const defaultOption = document.createElement("option");
      defaultOption.value = "";
      defaultOption.textContent = "Selecciona una opción";
      selectElement.appendChild(defaultOption);

      data.map((item) => {
        const value = item[dataShareValue];
        const optionElement = document.createElement("option");
        optionElement.value = value;
        optionElement.textContent = value;
        selectElement.appendChild(optionElement);
      });

      const swalTitleElement = document.getElementById("swal2-title");
      if (swalTitleElement) {
        swalTitleElement.insertAdjacentElement("afterend", selectElement);
      } else {
        console.error("swal2-title element not found.");
      }

      function handleSelectChange() {
        const selectElement = document.getElementById('dynamicSelectCodeSelling');

        if (!selectElement) {
          console.error(`Select element with id ${targetElementId} not found.`);
          return;
        }

        const inputElement = document.querySelector("input.marketingDataFieldValue");
        const selectedValue = selectElement.value;
        inputElement.value = selectedValue;
        inputElement.dispatchEvent(new Event('input')); // Trigger input event
      }

      selectElement.addEventListener("blur", handleSelectChange);
      selectElement.addEventListener("change", handleSelectChange);
      selectElement.addEventListener("trigger", handleSelectChange);

    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      hideLoader(); // Ocultar loader
    }
  }

  setTimeout(fetchData, 500);
}

$(window).load(function () {
  const codeLi = document.querySelector(".sb-b-codigovendedor");
  // codeLi.style.display = "none";
  // setTimeout(() => {
  const element = document.querySelector("a[data-share='codigovendedor']");
  if (element) {
    console.log("Element found:", element);
    element.addEventListener("click", () => {
      console.log('click code');
      fetchDataAndPopulateSelect(
        "/api/dataentities/CS/search?_fields=codigo",
        "dynamicSelectCodeSelling"
      );
    });
  } else {
    console.error("Element not found.");
  }
  if (codeLi) {
    codeLi.style.display = "block";
  }
  // }, 1000);
});


$(document).on('click', '.orderform-template-holder #client-profile-data .step.client-profile-data #edit-profile-data', () => {
  if (clientProfileData.alternateDocumentType() != "13 - Cédula de Ciudadanía") {
    clientProfileData.hasDifferentDocument(true);
    console.log("no cumple")
  } else {
    clientProfileData.hasDifferentDocument(false);
    console.log("cumple", "eliminando")
  }
})


$(document).on('click', '#is-corporate-client', function () {
  $('#client-company-ie').off('blur').on('blur', function () {
    const value = $(this).val();
    clientProfileData.stateInscription(value)
    clientProfileData.corporateDocument(value)
    $(document).on('click', '#go-to-shipping', function () {

      vtexjs.checkout.getOrderForm().then(function (orderForm) {
        let clientProfileData = orderForm.clientProfileData;
        console.log(clientProfileData)
        if (clientProfileData) {
          clientProfileData.stateInscription = value;
          clientProfileData.corporateDocument = value;
          vtexjs.checkout.sendAttachment('clientProfileData', clientProfileData);
        }

      });
    }
    )
  });
  $('#client-company-ie').on('input', function () {
    this.value = this.value.replace(/\D/g, '');
    if (this.value.length > 9) {
      this.value = this.value.slice(0, 9);
    }
  });
});

function validateFormAndToggleButton() {
  const $terms = $('#input__terms')
  const $department = $('#client-department')
  const $municipality = $('#client-municipality')
  const $address = $('#client-address')
  const $button = $('#go-to-shipping')

  if (!$button.length) return

  function updateButtonState() {
    const termsValid = !$terms.length || $terms.is(':checked')
    const departmentValid = !$department.length || $department.val().trim() !== ''
    const municipalityValid = !$municipality.length || $municipality.val().trim() !== ''
    const addressValid = !$address.length || $address.val().trim() !== ''
    
    const isValid = termsValid && departmentValid && municipalityValid && addressValid
    $button.prop('disabled', !isValid)
  }

  if ($terms.length) {
    $terms.off('change.validate').on('change.validate', updateButtonState)
  }

  if ($department.length) {
    $department.off('change.validate').on('change.validate', updateButtonState)
  }

  if ($municipality.length) {
    $municipality.off('change.validate').on('change.validate', updateButtonState)
  }

  if ($address.length) {
    $address.off('input.validate').on('input.validate', updateButtonState)
  }

  $(document).on('click', 'fieldset.box-client-info-pf', updateButtonState)

  updateButtonState()
}


function initValidationOnHash() {
  const validHashes = ['#/profile', '#/email']
  if (validHashes.includes(window.location.hash)) {
    $(document).ready(validateFormAndToggleButton)
    validateFormAndToggleButton()
  }
}

$(window).load(function () {
  initValidationOnHash()
})


$(window).on('hashchange', function () {
  initValidationOnHash()
})


function setupAdvisorSelect() {
    const advisorData = [
        { id: 0, name: "No Aplica / N/A" },
        { id: 1, name: "Angelo Beltran / ABELTRAN" },
        { id: 2, name: "Camilo Palacios / CPALACIOS" },
        { id: 3, name: "Claudia Espinosa / CESPINOSA" },
        { id: 4, name: "Diego Alegria / DALEGRIA" },
        { id: 5, name: "Douglas Weffer / DWEFFER" },
        { id: 6, name: "Elkin Valbuena / EVALBUENA" },
        { id: 7, name: "Jhonatan Sanchez / JSANCHEZ" },
        { id: 8, name: "Jose Acevedo / JACEVEDO" },
        { id: 9, name: "Maria Patricia Jimenez / MJIMENEZ" },
        { id: 10, name: "Maryi Cano / MCANO" },
        { id: 11, name: "Mayra Alejandra Arguello / MARGUELLO" },
        { id: 12, name: "Pablo Cervera / PCERVERA" },
        { id: 13, name: "Sandra Lizcano / SLIZCANO" },
        { id: 14, name: "Victor Muñoz / VMUÑOZ" }
    ];

    createAdvisorSelect(advisorData);
}

function createAdvisorSelect(advisorData) {
    const checkPaymentButton = setInterval(() => {
        const paymentButton = document.getElementById('payment-data-submit');
        
        if (paymentButton && !document.getElementById('advisor-select-container')) {
            const selectContainer = document.createElement('div');
            selectContainer.id = 'advisor-select-container';
            selectContainer.style.cssText = `
                margin: 15px 0;
                padding: 15px;
                background-color: #f8f9fa;
                border: 1px solid #dee2e6;
                border-radius: 8px;
            `;

            const label = document.createElement('label');
            label.htmlFor = 'advisor-select';
            label.textContent = 'Selecciona tu asesor comercial:';
            label.style.cssText = `
                display: block;
                margin-bottom: 8px;
                font-weight: 600;
                color: #495057;
                font-size: 14px;
            `;
            const select = document.createElement('select');
            select.id = 'advisor-select';
            select.style.cssText = `
                width: 100%;
                padding: 8px 12px;
                border: 1px solid #ced4da;
                border-radius: 4px;
                background-color: white;
                font-size: 14px;
                color: #495057;
                height: 38px;
            `;

            const defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = 'Selecciona un asesor...';
            defaultOption.selected = true;
            select.appendChild(defaultOption);

            advisorData.forEach(advisor => {
                const option = document.createElement('option');
                option.value = advisor.id;
                option.textContent = advisor.name;
                select.appendChild(option);
            });

            selectContainer.appendChild(label);
            selectContainer.appendChild(select);

            paymentButton.parentNode.insertBefore(selectContainer, paymentButton);
            
            select.addEventListener('change', function() {
                if (this.value) {
                    const orderForm = vtexjs.checkout.orderForm;
                    
                    const advisorId = this.value;
                    const advisorName = this.options[this.selectedIndex].textContent;
                    
                    const orderFormId = orderForm.orderFormId || 'Sin número de orden';
                    const totalValue = orderForm.value || 0;
                    
                    let totalizersValue = 0;
                    if (orderForm.totalizers && orderForm.totalizers.length > 0) {
                        const totalTotalizer = orderForm.totalizers.find(t => t.id === 'Items');
                        totalizersValue = totalTotalizer ? totalTotalizer.value : orderForm.value;
                    }
                    
                    const convertedValue = Math.round(totalizersValue / 100);
                    
                    saveAdvisorDataToLocalStorage(advisorId, advisorName, convertedValue, orderFormId);
                }
            });
            
            clearInterval(checkPaymentButton);
        }
    }, 500);

    setTimeout(() => {
        clearInterval(checkPaymentButton);
    }, 30000);
}

function getSelectedAdvisor() {
    const advisorSelect = document.getElementById('advisor-select');
    
    if (advisorSelect && advisorSelect.value) {
        const selectedOption = advisorSelect.options[advisorSelect.selectedIndex];
        const advisorData = {
            id: advisorSelect.value,
            name: selectedOption.textContent
        };
        
        const orderForm = vtexjs.checkout.orderForm;
        const orderFormId = orderForm.orderFormId || 'Sin número de orden';
        const totalValue = orderForm.value || 0;
        
        let totalizersValue = 0;
        if (orderForm.totalizers && orderForm.totalizers.length > 0) {
            const totalTotalizer = orderForm.totalizers.find(t => t.id === 'Items');
            totalizersValue = totalTotalizer ? totalTotalizer.value : orderForm.value;
        }
        
        return advisorData;
    }
    
    return null;
}

function saveAdvisorDataToLocalStorage(advisorId, advisorName, totalizersValue, orderFormId) {
    const advisorData = {
        advisorId: Number(advisorId), // Asegurar que sea número
        name: advisorName,
        value: totalizersValue,
        orderFormId: orderFormId,
        timestamp: new Date().toISOString(),
        status: 'pending' // Para indicar que aún no se ha enviado
    };
    
    localStorage.setItem('komatsu_advisor_data', JSON.stringify(advisorData));
}

async function sendToMasterData(advisorId, advisorName, totalizersValue) {
    
    const data = {
        advisorId: parseInt(advisorId),
        name: advisorName,
        value: Math.round(totalizersValue / 100)
    };

    const documentId = parseInt(advisorId).toString();
    const url = `/api/dataentities/TS/documents/${documentId}`;

    try {
        const response = await fetch(url, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            const result = await response.json();
            return result;
        } else {
            const errorText = await response.text();
            console.error('ERROR Master Data:', response.status, errorText);
            throw new Error(`HTTP ${response.status}: ${errorText}`);
        }
        
    } catch (error) {
        console.error('ERROR enviando a Master Data:', error);
        
        localStorage.setItem('advisor_data_backup', JSON.stringify({
            data: data,
            timestamp: new Date().toISOString(),
            error: error.message
        }));
        
        throw error;
    }
}

window.getSelectedAdvisor = getSelectedAdvisor;
window.sendToMasterData = sendToMasterData;
window.saveAdvisorDataToLocalStorage = saveAdvisorDataToLocalStorage;



